
    </div>
    <!-- /HK Wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url() ?>assett/vendors/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url() ?>assett/vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url() ?>assett/vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Slimscroll JavaScript -->
    <script src="<?php echo base_url() ?>assett/dist/js/jquery.slimscroll.js"></script>

    <!-- Fancy Dropdown JS -->
    <script src="<?php echo base_url() ?>assett/dist/js/dropdown-bootstrap-extended.js"></script>

    <!-- FeatherIcons JavaScript -->
    <script src="<?php echo base_url() ?>assett/dist/js/feather.min.js"></script>

    <!-- Toggles JavaScript -->
    <script src="<?php echo base_url() ?>assett/vendors/jquery-toggles/toggles.min.js"></script>
    <script src="<?php echo base_url() ?>assett/dist/js/toggle-data.js"></script>
	
	<!-- Counter Animation JavaScript -->
	<script src="<?php echo base_url() ?>assett/vendors/waypoints/lib/jquery.waypoints.min.js"></script>
	<script src="<?php echo base_url() ?>assett/vendors/jquery.counterup/jquery.counterup.min.js"></script>
	
	<!-- Easy pie chart JS -->
    <script src="<?php echo base_url() ?>assett/vendors/easy-pie-chart/dist/jquery.easypiechart.min.js"></script>
	
	<!-- Sparkline JavaScript -->
    <script src="<?php echo base_url() ?>assett/vendors/jquery.sparkline/dist/jquery.sparkline.min.js"></script>
	
	<!-- Morris Charts JavaScript -->
    <script src="<?php echo base_url() ?>assett/vendors/raphael/raphael.min.js"></script>
    <script src="<?php echo base_url() ?>assett/vendors/morris.js/morris.min.js"></script>
   
	<!-- EChartJS JavaScript -->
    <script src="<?php echo base_url() ?>assett/vendors/echarts/dist/echarts-en.min.js"></script>
    
	<!-- Peity JavaScript -->
    <script src="<?php echo base_url() ?>assett/vendors/peity/jquery.peity.min.js"></script>
   
	<!-- Apex JavaScript -->
    <script src="<?php echo base_url() ?>assett/vendors/apexcharts/dist/apexcharts.min.js"></script>
	
    <!-- Init JavaScript -->
    <script src="<?php echo base_url() ?>assett/dist/js/init.js"></script>
	<!-- <script src="<?php echo base_url() ?>assett/dist/js/dashboard3-data.js"></script> -->
	<script src="<?php echo base_url() ?>assett/dist/js/dashboard2-data.js"></script>
</body>

</html>