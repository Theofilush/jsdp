<?php

defined('BASEPATH') OR exit('Anda tidak boleh mengakses file ini secara langsung'); 
class M_login extends CI_Model{	
	var $tahun = 'tahun';
    function cek_login($table,$usn){		
		$this->db->where("email", $usn);		
		$this->db->or_where("ID_user",$usn);
		$query = $this->db->get("login");
    	
    	return $query;
		//return $this->db->get_where("t_login",$where);
	}	
	function hak_ak($usan){          
                $this->db->where("ID_user='$usan' OR email='$usan'");
                $hasil=$this->db->get('login');
                return $hasil->result();    	
	}
  	public function simpanUser($data){//function untuk menyimpan pengguna baru yg melakukan signup
		return $this->db->insert('t_login', $data);
	}
	function tampil_prodi(){ //query untuk menampilkan skema Penelitian pada form input dana yg bersumber UPJ
                $this->db->order_by('id_program', 'ASC');
                $query = $this->db->get('program_studi');        
                return $query->result();
	}	
	function get_prodi(){
		 //   $query = $this->db->query("SELECT merk,SUM(stok) AS stok FROM barang GROUP BY merk");
		//$this->db->order_by('id_program', 'ASC');
		$this->db->order_by('program_studi', 'ASC');
                $query = $this->db->get('program_studi');     
		if($query->num_rows() > 0){
			foreach($query->result() as $data){
		    		$hasil[] = $data;
			}
		return $hasil;
	    	}
	}	 
    function cek_id($id_user){     
        $this->db->where("ID_user", $id_user);		
		$query = $this->db->get("t_login");
        return $query->result();
	}
	
	public function add_year($data){
        return $this->db->insert($this->tahun, $data);
	} 
	
}

?>